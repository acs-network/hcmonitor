#!/bin/bash

datename=$1
iterations=$2
delay=$3

./pcm-df.x -r -di -csv=$datename/numa.csv -i=$iterations
./pcm-df.x -r -do -csv=$datename/numa.csv -i=$iterations
./pcm-df.x -r -cm -csv=$datename/numa.csv -i=$iterations
./pcm-df.x -r -iom -csv=$datename/numa.csv -i=$iterations
./pcm-df.x -r -prbfwd -csv=$datename/numa.csv -i=$iterations
./pcm-df.x -r -cs0prb -csv=$datename/numa.csv -i=$iterations
./pcm-df.x -r -cs1prb -csv=$datename/numa.csv -i=$iterations


