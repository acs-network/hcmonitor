#!/bin/bash

datename=$1
iterations=$2
delay=$3

./pcm.x -r -topdown -csv=$datename/core.csv -i=$iterations
./pcm.x -r -csv=$datename/core.csv -i=$iterations
./pcm.x -r -icache -csv=$datename/core.csv -i=$iterations
./pcm.x -r -l1 -csv=$datename/core.csv -i=$iterations
./pcm.x -r -l2 -csv=$datename/core.csv -i=$iterations
./pcm.x -r -insts -csv=$datename/core.csv -i=$iterations

./pcm.x -r -fppipe -csv=$datename/core.csv -i=$iterations
#front end stall, no instruction stall
./pcm.x -r -itlb -csv=$datename/core.csv -i=$iterations
./pcm.x -r -dtlb -csv=$datename/core.csv -i=$iterations
#badspec
./pcm.x -r -bran0 -csv=$datename/core.csv -i=$iterations


