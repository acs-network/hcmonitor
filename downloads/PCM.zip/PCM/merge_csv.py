#!/usr/bin/python3
import csv
import sys
import os
import pandas as pd

newdir = sys.argv[1]
lists = os.listdir(newdir) 
writer = pd.ExcelWriter(sys.argv[1] + '/' + "output.xlsx")

for i in range(0,len(lists)):
   txt_file = sys.argv[1] + "/" + lists[i]
   data = pd.read_csv(txt_file, delimiter=";", engine = "python", skip_blank_lines=False, names = list(range(0,5000)))
   sheetname = lists[i].split('.')[0]
   print(sheetname)
   data.to_excel(writer, sheetname, index=False)

writer.save()
