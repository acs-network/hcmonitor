#!/bin/bash

datename=$(date +%Y%m%d-%H%M%S)
iterations=$1
delay=1
mkdir $datename

./run_core.sh $datename $iteration $delay
./run_df.sh $datename $iteration $delay
